/*
 * manager_led.c
 *
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#include "manager_led.h"


// Definir os valores de tempo para um bit 0 e bit 1
static const Pulso_LED BIT_0_LED = {100, 100};
static const Pulso_LED BIT_1_LED = {100, 100};
static const Pulso_LED BIT_START_LED = {100, 100};
static const Pulso_LED BIT_FINALIZADOR_LED = {100, 100};

#define TAMANHO_VETOR_LED 21

static Pulso_LED vetor_pulsos_led[TAMANHO_VETOR_LED] = {

    BIT_START_LED,      // Pulso Start
    BIT_1_LED,          // Pulso 0 - SEMPRE EH 1
    BIT_0_LED,          // Pulso 1 - SEMPRE EH 0
    BIT_1_LED,          // Pulso 2
    BIT_0_LED,          // Pulso 3
    BIT_1_LED,          // Pulso 4
    BIT_0_LED,          // Pulso 5
    BIT_1_LED,          // Pulso 6
    BIT_0_LED,          // Pulso 7
    BIT_1_LED,          // Pulso 8
    BIT_0_LED,          // Pulso 9
    BIT_1_LED,          // Pulso 10
    BIT_0_LED,          // Pulso 11
    BIT_1_LED,          // Pulso 12
    BIT_0_LED,          // Pulso 13
    BIT_1_LED,          // Pulso 14
    BIT_0_LED,          // Pulso 15
    BIT_1_LED,          // Pulso 16
    BIT_0_LED,          // Pulso 17
    BIT_0_LED,          // Pulso 18 - SEMPRE EH 0
    BIT_FINALIZADOR_LED // Pulso FINALIZADOR

};

void MANAGER_Inicializar_Matriz_LED()
{
    Inicializar_Matriz_LED(vetor_pulsos_led);
}



void MANAGER_Alterar_Valor_LED(int16_t valor_decimal_led);






void MANAGER_Piscar_LED(void)
{
    Piscar_LED();
}


void MANAGER_Reiniciar_Sequencia_LED(void)
{
	Reiniciar_Sequencia_LED();
}
