#include "botao.h"

void Botao_Init(Botao *botao, GPIO_TypeDef *porta, uint16_t pino, TipoLigacao modo_ligacao, ModoAcionamento modo_acionamento, uint16_t tempo_debounce)
{

    botao->porta = porta;
    botao->pino = pino;
    botao->modo_ligacao = modo_ligacao;
    botao->modo_acionamento = modo_acionamento;

    if (modo_ligacao == PULLUP)
    {
        botao->estado_atual = 1;
        botao->estado_anterior = 1;
    }
    if (modo_ligacao == PULLDOWN)
    {
        botao->estado_atual = 0;
        botao->estado_anterior = 0;
    }

    botao->tempo_debounce = tempo_debounce;
    botao->contador = 0;

    botao->momento_acao_botao = SOLTO;
}

void Limpa_Acao_Botao(Botao *botao)
{
    botao->momento_acao_botao = SOLTO;
}

void Ler_Botao(Botao *botao)
{
    if (botao->modo_ligacao == PULLUP)
    {
        botao->estado_atual = HAL_GPIO_ReadPin(botao->porta, botao->pino);

        if (botao->modo_acionamento != MODO_CLIQUE)
        {

            if (botao->estado_atual == 0)
            {
                if (botao->momento_acao_botao != PRESSIONADO)
                {
                    botao->contador++;

                    // Passou do tempo de debounce? Confirma que foi APERTADO
                    if (botao->contador >= botao->tempo_debounce)
                    {
                        botao->momento_acao_botao = PRESSIONADO;
                        botao->contador = 0; // Zera para a próxima contagem
                    }
                }
            }

            else if (botao->estado_atual == 1)
            {
                // Só vira CLICADO se ele ESTAVA pressionado antes! (Garante que a pessoa apertou E soltou)
                if (botao->momento_acao_botao == PRESSIONADO)
                {
                    botao->contador++;
                    // Espera o debounce de soltura para evitar ruído ao abrir o contato
                    if (botao->contador >= botao->tempo_debounce)
                    {
                        botao->momento_acao_botao = CLICADO;
                        botao->contador = 0;
                    }
                }
            }
        }

        if (botao->modo_acionamento == MODO_PRESSIONAMENTO)
        {
            if (botao->estado_atual != botao->estado_anterior)
            {
                botao->contador++;

                // Passou do tempo de debounce? Confirma que foi APERTADO
                if (botao->contador >= botao->tempo_debounce)
                {
                    botao->momento_acao_botao = PRESSIONADO;
                    botao->contador = 0; // Zera para a próxima contagem
                    botao->estado_anterior = botao->estado_atual;
                }
            }
        }

        if (botao->modo_acionamento == MODO_SEGURANDO)
        {
            if (botao->estado_atual != botao->estado_anterior)
            {
                botao->contador++;

                if (botao->contador >= botao->tempo_debounce)
                {
                    botao->momento_acao_botao = SEGURADO;
                    botao->contador = 0; // Zera para a próxima contagem
                    botao->estado_anterior = botao->estado_atual;
                }
            }
        }
    }

    //=============================================================================

    if (botao->modo_ligacao == PULLDOWN)
    {
        botao->estado_atual = HAL_GPIO_ReadPin(botao->porta, botao->pino);

        if (botao->modo_acionamento != MODO_CLIQUE)
        {

            if (botao->estado_atual == 1)
            {
                if (botao->momento_acao_botao != PRESSIONADO)
                {
                    botao->contador++;

                    // Passou do tempo de debounce? Confirma que foi APERTADO
                    if (botao->contador >= botao->tempo_debounce)
                    {
                        botao->momento_acao_botao = PRESSIONADO;
                        botao->contador = 0; // Zera para a próxima contagem
                    }
                }
            }

            else if (botao->estado_atual == 0)
            {
                // Só vira CLICADO se ele ESTAVA pressionado antes! (Garante que a pessoa apertou E soltou)
                if (botao->momento_acao_botao == PRESSIONADO)
                {
                    botao->contador++;
                    // Espera o debounce de soltura para evitar ruído ao abrir o contato
                    if (botao->contador >= botao->tempo_debounce)
                    {
                        botao->momento_acao_botao = CLICADO;
                        botao->contador = 0;
                    }
                }
            }
        }

        if (botao->modo_acionamento == MODO_PRESSIONAMENTO)
        {
            if (botao->estado_atual != botao->estado_anterior)
            {
                botao->contador++;

                // Passou do tempo de debounce? Confirma que foi APERTADO
                if (botao->contador >= botao->tempo_debounce)
                {
                    botao->momento_acao_botao = PRESSIONADO;
                    botao->contador = 0; // Zera para a próxima contagem
                    botao->estado_anterior = botao->estado_atual;
                }
            }
        }

        if (botao->modo_acionamento == MODO_SEGURANDO)
        {
            if (botao->estado_atual != botao->estado_anterior)
            {
                botao->contador++;

                if (botao->contador >= botao->tempo_debounce)
                {
                    botao->momento_acao_botao = SEGURADO;
                    botao->contador = 0; // Zera para a próxima contagem
                    botao->estado_anterior = botao->estado_atual;
                }
            }
        }
    }
}
