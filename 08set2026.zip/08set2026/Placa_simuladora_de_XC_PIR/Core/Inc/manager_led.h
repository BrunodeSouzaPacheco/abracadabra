/*
 * manager_led.h
 
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_MANAGER_LED_H_
#define INC_MANAGER_LED_H_

#include "main.h"
#include "led.h"

void MANAGER_Piscar_LED(void);
void MANAGER_Alterar_Valor_LED(int16_t valor_decimal_led);
void MANAGER_Inicializar_Matriz_LED(void);
void MANAGER_Reiniciar_Sequencia_LED(void);

#endif /* INC_MANAGER_LED_H_ */