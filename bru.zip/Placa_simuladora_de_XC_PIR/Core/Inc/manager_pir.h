/*
 * manager_pir.h
 *
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_MANAGER_PIR_H_
#define INC_MANAGER_PIR_H_

#include "main.h"
#include "pir.h"

// Definir os valores de tempo para um bit 0 e bit 1
static const Pulso_PIR BIT_0_PIR = {9, 8};
static const Pulso_PIR BIT_1_PIR = {14, 2};
static const Pulso_PIR BIT_START_PIR = {90, 2};
static const Pulso_PIR BIT_FINALIZADOR_PIR = {0, 0};

#define TAMANHO_VETOR_PIR 21

void MANAGER_Executar_PIR(void);
void MANAGER_Alterar_Valor_PIR(int16_t valor_decimal_pir);
void MANAGER_Inicializar_Matriz_PIR(Nivel_Logico_PIR nivel_logico_pir);
void MANAGER_Reiniciar_Sequencia_PIR(void);

#endif /* INC_MANAGER_PIR_H_ */
