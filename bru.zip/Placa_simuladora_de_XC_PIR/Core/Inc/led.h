/*
 * led.h
 *
 *  Created on: 28 de ago. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_LED_H_
#define INC_LED_H_

#include "main.h"

// Estrutura para armazenar os tempos de um pulso (LED ligado/desligado)
typedef struct{
	uint32_t tempo_on_ms;   // Tempo que o LED permanece ligado (em ms ou ticks)
	uint32_t tempo_off_ms;  // Tempo que o LED permanece desligado (em ms ou ticks)
} Pulso_LED;


//=============================================================================
// Definição dos Estados do LED
//=============================================================================
#define ESTADO_LED_LIGADO    0
#define ESTADO_LED_DESLIGADO 1

//=============================================================================
// Protótipos das Funções
//=============================================================================

/**
 * @brief Executa a tarefa do LED no loop principal ou em uma interrupção de tempo.
 */
void Piscar_LED(void);

/**
 * @brief Inicia ou reinicia a sequência de piscadas do LED.
 */
void Reiniciar_Sequencia_LED(void);

/**
 * @brief Configura o ponteiro para a matriz/vetor com a sequência de pulsos.
 */
void Inicializar_Matriz_LED(Pulso_LED *matriz);
//=============================================================================

#endif /* INC_LED_H_ */
