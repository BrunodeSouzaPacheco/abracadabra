/*
 * manager_led.h

 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_GERADOR_SINAIS_H_
#define INC_GERADOR_SINAIS_H_

#include "main.h"

typedef enum{
    DESABILITADO = 0,
    HABILITADO = 1
}Oscilacao;

// Limites aceitos pelo hardware/algoritmo
#define VALOR_MINIMO_PICO_OSCILACAO   100
#define VALOR_MAXIMO_PICO_OSCILACAO   20000

#define TEMPO_MINIMO_OSCILACAO        1000
#define TEMPO_MAXIMO_OSCILACAO        10000

#define QTD_PERIODOS_MINIMO_OSCILACAO 1
#define QTD_PERIODOS_MAXIMO_OSCILACAO 10

int calcular_seno_matematico(int angulo);

// 1. Protótipo da função real que roda no STM32
void setup_oscilar_init(int valor_maximo, int tempo_ms, int qtd_periodos);

// 2. Macro Guard que intercepta a chamada no main.c
#define setup_oscilar(val, tempo, periodos) do { \
    _Static_assert(__builtin_constant_p(val) && \
                   ((val) >= VALOR_MINIMO_PICO_OSCILACAO) && \
                   ((val) <= VALOR_MAXIMO_PICO_OSCILACAO), \
                   "Erro de Build: 'val' deve ser constante e entre 100 e 20000"); \
    \
    _Static_assert(__builtin_constant_p(tempo) && \
                   ((tempo) >= TEMPO_MINIMO_OSCILACAO) && \
                   ((tempo) <= TEMPO_MAXIMO_OSCILACAO), \
                   "Erro de Build: 'tempo' deve ser constante e entre 1000 e 10000"); \
                   \
    _Static_assert(__builtin_constant_p(periodos) && \
                   ((periodos) >= QTD_PERIODOS_MINIMO_OSCILACAO) && \
                   ((periodos) <= QTD_PERIODOS_MAXIMO_OSCILACAO), \
                   "Erro de Build: 'periodos' deve ser constante e entre 1 e 10"); \
    \
    setup_oscilar_init((val), (tempo), (periodos)); \
} while(0)

int oscilar(void);

Oscilacao Get_Status_Oscilacao(void);
void Set_Status_Oscilacao(void);

#endif /* INC_GERADOR_SINAIS_H_ */
