/**
 ******************************************************************************
 * @file    Manager_chefe.h
 * @brief   Cabeçalho do Orquestrador Central da Aplicação.
 *          Responsável pela interface de alto nível com o main.c.
 ******************************************************************************
 */

#ifndef INC_MANAGER_CHEFE_H_
#define INC_MANAGER_CHEFE_H_

#include <stdint.h>

/*=============================================================================
 * Protótipos das Funções da Aplicação
 *============================================================================*/

/**
 * @brief  Inicializa todos os parâmetros de objetos, subsistemas (LED, PIR),
 *         gerador de sinais e botões de controle.
 */
void Manager_Chefe_Init(void);

/**
 * @brief  Processamento periódico de 1 ms.
 *         Responsável pela leitura e debounce dos botões e avanço da máquina
 *         de estados do LED.
 */
void Manager_Chefe_Processo_1ms(void);

/**
 * @brief  Processamento periódico de 16 ms.
 *         Responsável pela atualização do valor oscilado do PIR e execução
 *         da rajada de transmissão do sinal PIR.
 */
void Manager_Chefe_Processo_16ms(void);

#endif /* INC_MANAGER_CHEFE_H_ */
