/*
 * manager_led.h

 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_MANAGER_XC_H_
#define INC_MANAGER_XC_H_

#include "main.h"
#include "led.h"

// Definir os valores de tempo para um bit 0 e bit 1
static const Pulso_LED BIT_1_LED = {75, 25};
static const Pulso_LED BIT_0_LED = {25, 75};

#define TAMANHO_VETOR_LED 96

void MANAGER_Piscar_LED(void);
void MANAGER_QTD_Bits_Por_Parametro(uint16_t QTD_BITS_POR_PARAMETRO[]);
void MANAGER_Parametros_LED(uint16_t VALORES_PARAM[]);
void MANAGER_Inicializar_Matriz_LED(void);
void MANAGER_Reiniciar_Sequencia_LED(void);

#endif /* INC_MANAGER_XC _H_ */
