/*
 * manager_led.c
 *
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#include "manager_xc.h"

static uint16_t posicaovetor = 0;
static uint16_t contador_de_parametros = 0;
static uint16_t contador_de_bits = 0;

static uint16_t QTD_PARAMETROS_LED = 0;
static uint16_t QTD_DE_BITS_POR_PARAM[TAMANHO_VETOR_LED];

// inicializar o vetor de pulsos com qualquer valor
static Pulso_LED vetor_pulsos_led[TAMANHO_VETOR_LED];

void MANAGER_QTD_Bits_Por_Parametro(uint16_t QTD_BITS_POR_PARAMETRO[])
{
    while (QTD_BITS_POR_PARAMETRO[QTD_PARAMETROS_LED] != 0)
    {
        QTD_DE_BITS_POR_PARAM[QTD_PARAMETROS_LED] = QTD_BITS_POR_PARAMETRO[QTD_PARAMETROS_LED];

        QTD_PARAMETROS_LED++;
    }
}

void MANAGER_Parametros_LED(uint16_t VALORES_PARAM[])
{
    while (contador_de_parametros < QTD_PARAMETROS_LED)
    {
        // 1. Pega a quantidade de bits do parâmetro ATUAL
        uint16_t bits_do_parametro = QTD_DE_BITS_POR_PARAM[contador_de_parametros];

        for (contador_de_bits = 0; contador_de_bits < bits_do_parametro; contador_de_bits++)
        {
            // 2. Extrai o bit usando o parâmetro ATUAL (contador_de_parametros)
            uint16_t estado_dos_bits = (VALORES_PARAM[contador_de_parametros] >> ((bits_do_parametro - 1) - contador_de_bits)) & 1;

            if (estado_dos_bits == 1)
            {
                vetor_pulsos_led[posicaovetor] = BIT_1_LED;
            }
            else
            {
                vetor_pulsos_led[posicaovetor] = BIT_0_LED;
            }

            posicaovetor++;
        }

        contador_de_parametros++;
    }
}

void MANAGER_Inicializar_Matriz_LED()
{
    Inicializar_Matriz_LED(vetor_pulsos_led);
}

void MANAGER_Piscar_LED(void)
{
    Piscar_LED();
}

void MANAGER_Reiniciar_Sequencia_LED(void)
{
    Reiniciar_Sequencia_LED();
}
