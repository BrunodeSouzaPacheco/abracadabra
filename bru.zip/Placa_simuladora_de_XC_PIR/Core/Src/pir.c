/*
 * pir.c
 *
 *  Created on: 1 de set. de 2026
 *      Author: estagiario.epi
 */

#include "pir.h"

//=============================================================================
// Variáveis Estáticas (Privadas ao arquivo)
//=============================================================================

// Flag para habilitar ou desabilitar a execução da sequência do sensor PIR
static int habilita_contagem = 0;

// Variáveis de controle de tempo e estado (mantidas para compatibilidade lógica)
static uint32_t contador_de_tempo;
static uint32_t tempo_destino;
static uint32_t estado_atual;

// Índice do pulso atual da sequência PIR
static uint32_t indice_pulso = 0;

// Ponteiro para a matriz/vetor com a sequência de tempos de pulso
static Pulso_PIR *matriz_pulsos_pir = NULL;

// Define o nível lógico para LIGAR ou DESLIGAR o PIR conforme configuração do sinal
static uint32_t NIVEL_LOGICO_LIGAR_PIR = 1;
static uint32_t NIVEL_LOGICO_DESLIGAR_PIR = 0;

//=============================================================================
// Implementação das Funções
//=============================================================================

/**
 * @brief Reinicia o índice de pulsos, configura os parâmetros iniciais,
 *        inverte a flag de habilitação da contagem (toggle) e altera o estado do LED indicativo.
 */
void Reiniciar_Sequencia_PIR(void)
{
	indice_pulso = 0;
	contador_de_tempo = 0;
	tempo_destino = matriz_pulsos_pir[indice_pulso].tempo_on;
	estado_atual = 0;

	// Inverte o estado da flag de habilitação (se era 0 vira 1, se era 1 vira 0)
	habilita_contagem = habilita_contagem ? 0 : 1;

	// Inverte o estado lógico do pino do LED do PIR
	//HAL_GPIO_TogglePin(LED_SINALIZADOR_PIR_GPIO_Port, LED_SINALIZADOR_PIR_Pin);
}

/**
 * @brief Configura o ponteiro para a matriz de pulsos do PIR e define a polaridade
 *        do sinal lógico (Ativo Alto ou Ativo Baixo).
 *
 * @param matriz Ponteiro para a sequência de estrutura Pulso_PIR.
 * @param nivel_logico Define se o PIR aciona em nível ALTO (1) ou BAIXO (0).
 */
void Inicializar_Matriz_PIR(Pulso_PIR *matriz, Nivel_Logico_PIR nivel_logico)
{
	matriz_pulsos_pir = matriz;

	if (nivel_logico == PIR_ATIVO_ALTO)
	{
		NIVEL_LOGICO_LIGAR_PIR = 1;
		NIVEL_LOGICO_DESLIGAR_PIR = 0;
	}
	else
	{
		NIVEL_LOGICO_LIGAR_PIR = 0;
		NIVEL_LOGICO_DESLIGAR_PIR = 1;
	}
}

/**
 * @brief Executa a geração de pulsos do PIR bloqueando interrupções.
 *        Muda o estado do pino do PIR em tempo real utilizando o contador do Timer 3 (TIM3->CNT).
 */
void Executar_PIR(void)
{
	if (habilita_contagem >= 1)
	{
		// Desabilita interrupções globais para garantir precisão de tempo (bloqueante)
		__disable_irq();

		// Percorre a matriz de pulsos até encontrar o elemento de parada (tempo_on == 0 e tempo_off == 0)
		while (matriz_pulsos_pir[indice_pulso].tempo_on != 0 && matriz_pulsos_pir[indice_pulso].tempo_off != 0)
		{
			/* 1. Liga o pino do PIR e aguarda a contagem real de tempo_on usando TIM3 */
			HAL_GPIO_WritePin(SINAL_PIR_GPIO_Port, SINAL_PIR_Pin, NIVEL_LOGICO_LIGAR_PIR);
			TIM3->CNT = 0; // Zera o contador do timer 3

			tempo_destino = matriz_pulsos_pir[indice_pulso].tempo_on;

			// Bloqueia a execução (polling) até que o contador atinja o tempo ligado desejado
			while (TIM3->CNT < tempo_destino)
			{

			}

			/* 2. Desliga o pino do PIR e aguarda a contagem real de tempo_off usando TIM3 */
			HAL_GPIO_WritePin(SINAL_PIR_GPIO_Port, SINAL_PIR_Pin, NIVEL_LOGICO_DESLIGAR_PIR);
			TIM3->CNT = 0; // Zera o contador do timer 3

			tempo_destino = matriz_pulsos_pir[indice_pulso].tempo_off;

			// Bloqueia a execução (polling) até que o contador atinja o tempo desligado desejado
			while (TIM3->CNT < tempo_destino)
			{

			}

			// Avança para o próximo pulso da matriz
			indice_pulso++;
		}

		// Garante que o pino do PIR permaneça desligado após o encerramento da sequência
		HAL_GPIO_WritePin(SINAL_PIR_GPIO_Port, SINAL_PIR_Pin, NIVEL_LOGICO_DESLIGAR_PIR);

		// habilita_contagem = 0; // Mantido comentado conforme código original

		// Reseta o índice de pulsos para a próxima execução
		indice_pulso = 0;

		// Reabilita as interrupções globais
		__enable_irq();
	}
}
