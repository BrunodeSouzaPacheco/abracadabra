
#include "gerador_sinais.h"

static uint16_t valor_maximo_usado;
static uint16_t tempo_usado;
static uint16_t qtd_periodos_usado;

Oscilacao flag = DESABILITADO;

/**
 * @brief Inicializa os parâmetros do gerador uma única vez no setup
 */
void setup_oscilar_init(int valor_maximo, int tempo_ms, int qtd_periodos)
{
    valor_maximo_usado = valor_maximo;
    tempo_usado = tempo_ms;
    qtd_periodos_usado = qtd_periodos;
}

/**
 * Calcula a onda de seno suave de 0 a 360 graus usando a fórmula de Bhaskara.
 * Retorna um valor entre -10000 e +10000.
 */

int calcular_seno_matematico(int angulo)
{
    // Garante que o ângulo fique dentro de 0 a 359 graus
    angulo = angulo % 360;
    if (angulo < 0)
        angulo += 360;

    int sinal = 1;
    // Se estiver no semi-ciclo negativo (180 a 360), espelha o ângulo
    if (angulo >= 180)
    {
        angulo -= 180;
        sinal = -1;
    }
    // Aplicação direta da Fórmula de Bhaskara I:
    int x = angulo;
    int numerador = 4 * x * (180 - x);
    int denominador = 40500 - (x * (180 - x));

    // Multiplica por 10000 ANTES da divisão para não zerar os decimais no C
    return sinal * ((numerador * 10000) / denominador);
}

int oscilar(void)
{
    static int passo_atual = 0;
    // 1. Agora o cálculo usa o tempo configurado no setup, e não mais um define fixo!
    int total_passos = tempo_usado / 16;

    flag = HABILITADO;

    if (total_passos <= 0)
        return 0;
    if (passo_atual >= total_passos)
    {
        passo_atual = 0;
        flag = DESABILITADO;
        HAL_GPIO_WritePin(LED_SINALIZADOR_PIR_GPIO_Port, LED_SINALIZADOR_PIR_Pin, 1);
    }
    int resultado = 0;
    if (passo_atual < total_passos)
    {
        // 2. Usa a quantidade de períodos configurada no setup!
        int angulo_total = qtd_periodos_usado * 360;
        int angulo_atual = (passo_atual * angulo_total) / total_passos;
        // 3. Usa o valor de pico configurado no setup!
        int amplitude_atual = valor_maximo_usado - ((valor_maximo_usado * passo_atual) / total_passos);
        int valor_seno = calcular_seno_matematico(angulo_atual);
        resultado = (amplitude_atual * valor_seno) / 10000;
    }
    else
    {
        resultado = 0;
    }
    passo_atual++;
    return resultado;
}

Oscilacao Get_Status_Oscilacao(void){
    return flag;
}

void Set_Status_Oscilacao(void){
    flag = HABILITADO;
}