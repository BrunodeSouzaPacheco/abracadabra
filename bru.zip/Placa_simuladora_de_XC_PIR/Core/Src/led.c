#include "led.h"



//=============================================================================
// Variáveis Globais / Estáticas
//=============================================================================

// Flag para habilitar/desabilitar a execução da contagem do LED
uint32_t contagem_habilitada = 0;

// Contador incremental para controlar o tempo decorrido no estado atual
uint32_t contador_tempo = 0;

// Duração do estado atual (tempo ON ou tempo OFF)
uint32_t tempo_alvo_limite = 0;

// Estado atual da máquina de estados do LED (0 = LIGADO, 1 = DESLIGADO)
uint32_t estado_led_atual = ESTADO_LED_LIGADO;

// Índice do pulso atual dentro do vetor de sequências
uint32_t indice_pulso_atual = 0;

// Limite máximo de pulsos (não utilizado na lógica original)
uint32_t maximo_de_pulsos = 10;

// Ponteiro para a sequência de pulsos configurada pelo usuário
static Pulso_LED *matriz_pulsos_led = NULL;

//=============================================================================
// Implementação das Funções
//=============================================================================

/**
 * @brief Configura o ponteiro para a tabela/vetor de sequência de pulsos.
 */
void Inicializar_Matriz_LED(Pulso_LED *matriz)
{
	matriz_pulsos_led = matriz;
}

/**
 * @brief Reinicia a sequência de pisca e habilita a contagem do LED.
 */
void Reiniciar_Sequencia_LED(void)
{
	// Se desejar ignorar chamadas se já estiver contando, descomente a linha abaixo:
	// if(contagem_habilitada) return;
	indice_pulso_atual = 0;
	contador_tempo = 0;
	estado_led_atual = ESTADO_LED_LIGADO;

	// Carrega o primeiro tempo de acendimento (ON)
	tempo_alvo_limite = matriz_pulsos_led[indice_pulso_atual].tempo_on_ms;

	// Ativa a execução do controle do LED
	contagem_habilitada = 1;
}

/**
 * @brief Maquina de estados da tarefa do LED (deve ser chamada periodicamente).
 */
void Piscar_LED(void)
{

	// Verifica se o controle de contagem está ativo
	if (contagem_habilitada >= 1)
	{

		// Incrementa o contador de tempo e verifica se atingiu o tempo limite programado
		if (++contador_tempo >= tempo_alvo_limite)
		{

			// Transição de estado: se estava no estado LIGADO
			if (estado_led_atual == ESTADO_LED_LIGADO)
			{
				// Próximo tempo alvo será o tempo em que o LED deve ficar DESLIGADO
				tempo_alvo_limite = matriz_pulsos_led[indice_pulso_atual].tempo_off_ms;

				// Transita para o estado DESLIGADO
				estado_led_atual = ESTADO_LED_DESLIGADO;
				contador_tempo = 0;
			}

			// Transição de estado: se estava no estado DESLIGADO
			else
			{

				// Avança para o próximo pulso da sequência
				indice_pulso_atual++;

				// Próximo tempo alvo será o tempo em que o LED deve ficar LIGADO
				tempo_alvo_limite = matriz_pulsos_led[indice_pulso_atual].tempo_on_ms;

				// Transita para o estado LIGADO
				estado_led_atual = ESTADO_LED_LIGADO;
				contador_tempo = 0;
			}
		}
		// Atualiza o nível lógico do pino GPIO enquanto o tempo alvo não for atingido
		else
		{
			HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, estado_led_atual);
		}
	}
}
