/**
 ******************************************************************************
 * @file    Manager_chefe.c
 * @brief   Implementação do Orquestrador Central da Aplicação.
 *          Centraliza os parâmetros de simulação, objetos de hardware (botões)
 *          e coordena os gerentes de subsistema (LED, PIR, Sinais).
 ******************************************************************************
 */

#include "Manager_chefe.h"
#include "main.h"

#include "manager_led.h"
#include "manager_pir.h"
#include "botao.h"
#include "gerador_sinais.h"

/*=============================================================================
 * Parâmetros de Simulação e Configurações de Protocolo
 *============================================================================*/

// Tabela de formatação de bits do protocolo LED (0 é o terminador do vetor)
static uint16_t QTD_Bits_Por_Parametro_LED[] = {1, 3, 4, 2, 2, 2, 0};

// Valores configurados para cada parâmetro da simulação do LED
static uint16_t Valores_Parametros_LED[] = {1, 0, 2, 1, 3, 2};

/*=============================================================================
 * Instâncias de Objetos e Variáveis de Estado da Aplicação
 *============================================================================*/

static Botao Botao_LED;
static Botao Botao_PIR;

static int32_t valor_variado_pir = 0;

/*=============================================================================
 * Implementação das Funções do Manager Chefe
 *============================================================================*/

void Manager_Chefe_Init(void)
{
    /* 1. Configuração e inicialização dos parâmetros do protocolo de LED */
    MANAGER_QTD_Bits_Por_Parametro(QTD_Bits_Por_Parametro_LED);
    MANAGER_Parametros_LED(Valores_Parametros_LED);
    MANAGER_Inicializar_Matriz_LED();

    /* 2. Inicialização do subsistema PIR */
    MANAGER_Inicializar_Matriz_PIR(PIR_ATIVO_ALTO);

    /* 3. Inicialização do gerador de oscilação matemática do PIR (Pico, Tempo ms, Períodos) */
    setup_oscilar(5000, 5000, 5);

    /* 4. Inicialização dos Botões (Debounce de 50ms, modo de clique e pull-up) */
    Botao_Init(&Botao_LED, BOTAO_LED_GPIO_Port, BOTAO_LED_Pin, PULLUP, MODO_CLIQUE, 50);
    Botao_Init(&Botao_PIR, BOTAO_PIR_GPIO_Port, BOTAO_PIR_Pin, PULLUP, MODO_CLIQUE, 50);

    /* 5. Estado inicial dos LEDs indicadores */
    HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(LED_SINALIZADOR_PIR_GPIO_Port, LED_SINALIZADOR_PIR_Pin, GPIO_PIN_SET);
}

void Manager_Chefe_Processo_1ms(void)
{
    /* A. Leitura do Botão do LED e avanço do protocolo de pulsos do LED */
    Ler_Botao(&Botao_LED);

    if (Botao_LED.momento_acao_botao == CLICADO)
    {
        Limpa_Acao_Botao(&Botao_LED);
        MANAGER_Reiniciar_Sequencia_LED();
    }

    MANAGER_Piscar_LED();

    /* B. Leitura do Botão do PIR */
    Ler_Botao(&Botao_PIR);

    if (Botao_PIR.momento_acao_botao == CLICADO)
    {
        Limpa_Acao_Botao(&Botao_PIR);
        Set_Status_Oscilacao();
        HAL_GPIO_WritePin(LED_SINALIZADOR_PIR_GPIO_Port, LED_SINALIZADOR_PIR_Pin, GPIO_PIN_RESET);
    }
}

void Manager_Chefe_Processo_16ms(void)
{
    /* Se a simulação do PIR foi disparada, calcula o próximo ponto senoidal */
    if (Get_Status_Oscilacao() == HABILITADO)
    {
        valor_variado_pir = oscilar();
        MANAGER_Alterar_Valor_PIR((int16_t)valor_variado_pir);
    }
    MANAGER_Reiniciar_Sequencia_PIR();
    MANAGER_Executar_PIR();
}
