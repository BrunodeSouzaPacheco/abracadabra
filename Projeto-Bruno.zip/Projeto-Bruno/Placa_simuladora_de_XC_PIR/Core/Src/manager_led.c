/*
 * manager_led.c
 *
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#include "manager_led.h"



// inicializar o vetor de pulsos com qualquer valor
static Pulso_LED vetor_pulsos_led[TAMANHO_VETOR_LED] = {

    BIT_0_LED, // Pulso 0
    BIT_0_LED, // Pulso 1
    BIT_0_LED, // Pulso 2
    BIT_0_LED, // Pulso 3
    BIT_0_LED, // Pulso 4
    BIT_0_LED, // Pulso 5
    BIT_0_LED, // Pulso 6
    BIT_0_LED, // Pulso 7
    BIT_0_LED, // Pulso 8
    BIT_0_LED, // Pulso 9
    BIT_0_LED, // Pulso 10
    BIT_0_LED, // Pulso 11
    BIT_0_LED, // Pulso 12
    BIT_0_LED, // Pulso 13
    BIT_0_LED, // Pulso 14
    BIT_0_LED, // Pulso 15
    BIT_0_LED, // Pulso 16
    BIT_0_LED, // Pulso 17
    BIT_0_LED, // Pulso 18
    BIT_0_LED, // Pulso 19
    BIT_0_LED, // Pulso 20
    BIT_0_LED, // Pulso 21
    BIT_0_LED, // Pulso 22
    BIT_0_LED, // Pulso 23

};

void MANAGER_Inicializar_Matriz_LED()
{
    Inicializar_Matriz_LED(vetor_pulsos_led);
}

void MANAGER_Parâmetros_LED(uint16_t SVN, uint16_t TEMPO, uint16_t FOTO, uint16_t SENSIBILIDADE)
{
	uint16_t     posicaovetor = 0;
    uint16_t     i = 0; // Variavel para correr os 16 BITS do FOR

    for (i = 0; i < QTD_DE_BITS_SVN; i++)
    {

        uint16_t estado_dos_bits_snv = (SVN >> ((QTD_DE_BITS_SVN-1) - i)) & 1;

        if (estado_dos_bits_snv == 1)
        {
            vetor_pulsos_led[posicaovetor] = BIT_1_LED;
        }
        else
        {
            vetor_pulsos_led[posicaovetor] = BIT_0_LED;
        }
    posicaovetor++;
    }


    for (i = 0; i < QTD_DE_BITS_TEMPO; i++)
    {
        uint16_t estado_dos_bits_tempo = (TEMPO >> ((QTD_DE_BITS_TEMPO - 1) - i)) & 1;

        if (estado_dos_bits_tempo == 1)
        {
            vetor_pulsos_led[posicaovetor] = BIT_1_LED;
        }
        else
        {
            vetor_pulsos_led[posicaovetor] = BIT_0_LED;
        }
    posicaovetor++;
    }


    for (i = 0; i < QTD_DE_BITS_FOTO; i++)
    {
        uint16_t estado_dos_bits_foto = (FOTO >> ((QTD_DE_BITS_FOTO - 1) - i)) & 1;

        if (estado_dos_bits_foto == 1)
        {
            vetor_pulsos_led[posicaovetor] = BIT_1_LED;
        }
        else
        {
            vetor_pulsos_led[posicaovetor] = BIT_0_LED;
        }
    posicaovetor++;
    }


    for (i = 0; i < QTD_DE_BITS_SENSIBILIDADE; i++)
    {
        uint16_t estado_dos_bits_sensibilidade = (SENSIBILIDADE >> ((QTD_DE_BITS_SENSIBILIDADE - 1 ) - i)) & 1;

        if (estado_dos_bits_sensibilidade == 1)
        {
            vetor_pulsos_led[posicaovetor] = BIT_1_LED;
        }
        else
        {
            vetor_pulsos_led[posicaovetor] = BIT_0_LED;
        }
    }
    posicaovetor++;
}

void MANAGER_Piscar_LED(void)
{
    Piscar_LED();
}

void MANAGER_Reiniciar_Sequencia_LED(void)
{
    Reiniciar_Sequencia_LED();
}
