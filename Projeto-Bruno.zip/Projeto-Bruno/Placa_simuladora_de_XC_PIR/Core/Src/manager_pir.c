/*
 * manager_pir.c
 *
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#include "manager_pir.h"

// Definir os valores de tempo para um bit 0 e bit 1
static const Pulso_PIR BIT_0_PIR = {9, 8};
static const Pulso_PIR BIT_1_PIR = {14, 2};
static const Pulso_PIR BIT_START_PIR = {90, 2};
static const Pulso_PIR BIT_FINALIZADOR_PIR = {0, 0};

#define TAMANHO_VETOR_PIR 21

static Pulso_PIR vetor_pulsos_pir[TAMANHO_VETOR_PIR] = {

    BIT_START_PIR,      // Pulso Start
    BIT_1_PIR,          // Pulso 0 - SEMPRE EH 1
    BIT_0_PIR,          // Pulso 1 - SEMPRE EH 0
    BIT_1_PIR,          // Pulso 2
    BIT_0_PIR,          // Pulso 3
    BIT_1_PIR,          // Pulso 4
    BIT_0_PIR,          // Pulso 5
    BIT_1_PIR,          // Pulso 6
    BIT_0_PIR,          // Pulso 7
    BIT_1_PIR,          // Pulso 8
    BIT_0_PIR,          // Pulso 9
    BIT_1_PIR,          // Pulso 10
    BIT_0_PIR,          // Pulso 11
    BIT_1_PIR,          // Pulso 12
    BIT_0_PIR,          // Pulso 13
    BIT_1_PIR,          // Pulso 14
    BIT_0_PIR,          // Pulso 15
    BIT_1_PIR,          // Pulso 16
    BIT_0_PIR,          // Pulso 17
    BIT_0_PIR,          // Pulso 18 - SEMPRE EH 0
    BIT_FINALIZADOR_PIR // Pulso FINALIZADOR
};

void MANAGER_Inicializar_Matriz_PIR(Nivel_Logico_PIR nivel_logico_pir)
{
	Inicializar_Matriz_PIR(vetor_pulsos_pir, nivel_logico_pir);
}



void MANAGER_Alterar_Valor_PIR(int16_t valor_decimal_pir)
{
	int16_t i = 0; //Variavel para correr os 16 BITS do FOR

    // 1. Cabeçalho fixo
	vetor_pulsos_pir[0] = BIT_START_PIR;
	vetor_pulsos_pir[1] = BIT_1_PIR;
	vetor_pulsos_pir[2] = BIT_0_PIR;
    // 2. Insere os 16 bits da variável (MSB primeiro, da esquerda para a direita)
    for (int i = 0; i < 16; i++)
    {
        uint8_t estado_do_bit = (valor_decimal_pir >> (15 - i)) & 1;

        if (estado_do_bit == 1) 
        {
        	vetor_pulsos_pir[3 + i] = BIT_1_PIR;
        } 
        else 
        {
        	vetor_pulsos_pir[3 + i] = BIT_0_PIR;
        }
    }

    // 3. Rodapé fixo
    vetor_pulsos_pir[19] = BIT_0_PIR;
    vetor_pulsos_pir[20] = BIT_FINALIZADOR_PIR;

    i++;
}



void MANAGER_Executar_PIR(void)
{
    Executar_PIR();
}



void MANAGER_Reiniciar_Sequencia_PIR(void)
{
	Reiniciar_Sequencia_PIR();
}
