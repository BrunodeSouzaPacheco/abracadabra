/*
 * manager_led.h
 
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_MANAGER_LED_H_
#define INC_MANAGER_LED_H_

#include "main.h"
#include "led.h"

// Definir os valores de tempo para um bit 0 e bit 1
static const Pulso_LED BIT_1_LED = {25, 75};
static const Pulso_LED BIT_0_LED = {75, 25};

#define TAMANHO_VETOR_LED 24
#define QTD_DE_BITS_SVN 16
#define QTD_DE_BITS_TEMPO 4
#define QTD_DE_BITS_FOTO 2
#define QTD_DE_BITS_SENSIBILIDADE 2


void MANAGER_Piscar_LED(void);
void MANAGER_Parâmetros_LED(uint16_t SVN, uint16_t TEMPO, uint16_t FOTO, uint16_t SENSIBILIDAE);
void MANAGER_Inicializar_Matriz_LED(void);
void MANAGER_Reiniciar_Sequencia_LED(void);

#endif /* INC_MANAGER_LED_H_ */
