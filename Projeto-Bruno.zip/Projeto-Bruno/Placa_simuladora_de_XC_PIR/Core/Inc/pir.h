/*
 * pir.h
 *
 *  Created on: 1 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_PIR_H_
#define INC_PIR_H_
#include "main.h"

typedef struct
{
  uint32_t tempo_on;
  uint32_t tempo_off;
} Pulso_PIR;



typedef enum
{
  PIR_ATIVO_BAIXO = 0,
  PIR_ATIVO_ALTO = 1
} Nivel_Logico_PIR;

//==========================

void Executar_PIR(void);
void Reiniciar_Sequencia_PIR(void);
void Inicializar_Matriz_PIR(Pulso_PIR *matriz, Nivel_Logico_PIR nivel_logico);

#endif /* INC_PIR_H_ */
