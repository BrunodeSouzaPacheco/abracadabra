/*
 * manager_pir.h
 *
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_MANAGER_PIR_H_
#define INC_MANAGER_PIR_H_

#include "main.h"
#include "pir.h"

void MANAGER_Executar_PIR(void);
void MANAGER_Alterar_Valor_PIR(int16_t valor_decimal_pir);
void MANAGER_Inicializar_Matriz_PIR(Nivel_Logico_PIR nivel_logico_pir);
void MANAGER_Reiniciar_Sequencia_PIR(void);

#endif /* INC_MANAGER_PIR_H_ */
