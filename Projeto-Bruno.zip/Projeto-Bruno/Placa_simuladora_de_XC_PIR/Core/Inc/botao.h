#ifndef Botao_H
#define Botao_H
#include "main.h"

// 1. Tipos de ligação elétrica do pino
typedef enum
{
    PULLUP = 0,  // Pressionado = GND (0V / LOW)
    PULLDOWN = 1 // Pressionado = VCC (5V / HIGH)
} TipoLigacao;

// 2. Modos de acionamento
typedef enum
{
    MODO_CLIQUE = 0,         // Ativa só no momento que solta (borda de descida/subida)
    MODO_PRESSIONAMENTO = 1, // Ativa já na hora que pressiona, ele continua funcionando mesmo se soltar
    MODO_SEGURANDO = 2       // Ativa continuamente enquanto estiver apertamento
} ModoAcionamento;

typedef enum
{
    SOLTO = 0,
    PRESSIONADO = 1,
    SEGURADO = 2,
    CLICADO = 3
} MomentoAcaoBotao;

// 4. Estrutura principal do Botão
typedef struct
{
    GPIO_TypeDef *porta; // Me diz a porta que o botão está conectado (o ioc gera essa porta automaticamente)

    uint16_t pino; // Me diz o pino que o botão está conectado (o ioc gera esse pino automaticamente)

    TipoLigacao modo_ligacao;         // Me diz se o botao esta em pullup ou pulldown
    ModoAcionamento modo_acionamento; // Diz se o botao será acionado por clique (aperta e solta [executa só quando apertar e soltar]), pressionamento (logo ao apertar executa ação, solta e ainda faz ação) ou segurando (executar ação enquanto estiver apertando)

    uint16_t estado_atual;    // Me diz se o botão está apertado ou não (1 = apertado, 0 = solto);
    uint16_t estado_anterior; // Me diz se o botão estava apertado ou não (1 = apertado, 0 = solto);
    uint16_t tempo_debounce;  // Me diz o tempo de debounce do botão (em ms);

    uint16_t contador; // Usado para contar o tempo de debounce do botão (em ms);

    MomentoAcaoBotao momento_acao_botao; // Me diz se o botão foi clicado, pressionado ou solto
} Botao;

//  Botao_Init(ponteiro que aponta para a variavel "botao", porta do botao, pino do botao, tempo de debounce, modo de ligacao do botao (pullup ou pulldown));
void Botao_Init(Botao *botao, GPIO_TypeDef *porta, uint16_t pino, TipoLigacao modo_ligacao, ModoAcionamento modo_acionamento, uint16_t tempo_debounce); // Inicializa o botão (deve ser chamado no setup do programa)

void Limpa_Acao_Botao(Botao *botao); // Limpa a ação do botão (para não ficar acionando a função várias vezes)

void Ler_Botao(Botao *botao); // Executa a função do botão (deve ser chamada dentro do loop principal do programa)

#endif // Botao_H
