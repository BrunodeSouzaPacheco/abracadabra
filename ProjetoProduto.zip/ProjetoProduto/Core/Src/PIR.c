/*
 * pir.c
 *
 *  Created on: 1 de set. de 2026
 *      Author: estagiario.epi
 */

#include "PIR.h"

// Flags e Estados de Controle
static uint8_t sequencia_ativa = 0; // 1 = Executando, 0 = Parado
static uint8_t estado_led = 0;      // 0 = Nível Baixo, 1 = Nível Alto

// Contadores e Limites de Tempo
static uint16_t duracao_etapa_ms = 0;
static uint16_t indice_pulso = 0;

// Ponteiro para a matriz de tempos configurada pelo usuário
static PulsoPIR *tabela_pulsos_pir = NULL;

// Salva a matriz de tempos que será utilizada pelo PIR.
// matriz Ponteiro para o array do tipo PulsoPIR.
void Configura_Matriz_PIR(PulsoPIR *matriz)
{
    tabela_pulsos_pir = matriz;
}

// Prepara as variáveis iniciais para disparar a sequência de pisca do PIR.
void Configura_Piscadas_PIR(void)
{
    // Garante que existe uma matriz configurada antes de rodar
    if (tabela_pulsos_pir == NULL)
        return;

    indice_pulso = 0;
    estado_led = 0;
    duracao_etapa_ms = tabela_pulsos_pir[indice_pulso].tempo_on;

    sequencia_ativa = 1; // Habilita a execução do loop bloqueante
}

// Executa a sequência de pulsos do PIR de forma bloqueante usando o TIM3.
void Executa_PIR(void)
{
    // Executa apenas se a sequência tiver sido habilitada pela Configura_Piscadas_PIR
    if (sequencia_ativa >= 1)
    {
        // Trava interrupções externas para evitar concorrência durante o ciclo de tempo preciso
        __disable_irq();

        // Loop principal: Roda enquanto NÃO encontrar a terminação {tempo_on = 0, tempo_off = 0}
        while (!(tabela_pulsos_pir[indice_pulso].tempo_on == 0 && tabela_pulsos_pir[indice_pulso].tempo_off == 0))
        {
            // Reseta o contador interno do Hardware TIM3
            TIM3->CNT = 0;

            // Loop de espera bloqueante baseado no registrador do TIM3
            while (TIM3->CNT <= (duracao_etapa_ms - 2))
            {
                HAL_GPIO_WritePin(LED_PIR_GPIO_Port, LED_PIR_Pin, (GPIO_PinState)estado_led);
            }

            // Alterna os estados e carrega os novos tempos
            if (estado_led)
            {
                estado_led = 0;
                indice_pulso++; // Avança para o próximo pulso da matriz
                duracao_etapa_ms = tabela_pulsos_pir[indice_pulso].tempo_on;
            }
            else
            {
                estado_led = 1;
                duracao_etapa_ms = tabela_pulsos_pir[indice_pulso].tempo_off;
            }
        }

        // Garante que o LED fique desligado ao final da sequência
        HAL_GPIO_WritePin(LED_PIR_GPIO_Port, LED_PIR_Pin, GPIO_PIN_RESET);

        // Reseta o controle do sistema
        sequencia_ativa = 0;
        indice_pulso = 0;

        // Reabilita as interrupções do sistema
        __enable_irq();
    }
}