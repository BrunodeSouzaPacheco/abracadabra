#include "Manager.h"

void Gerenciador_Manager(ModuloPeriferico *modulo)
{
    // Verifica se o ponteiro é válido antes de chamar
    if (modulo != NULL) 
    {
        if (modulo->configurar != NULL) {
            modulo->configurar(); // Chama a função de setup/set
        }
        
        if (modulo->executar != NULL) {
            modulo->executar();   // Chama a função principal
        }
    }
}