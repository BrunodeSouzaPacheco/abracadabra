#include "PulsosLED.h"

// Flags e Estados Lógicos de Controle
static uint8_t sequencia_ativa = 0; // 1 = Executando, 0 = Parado
static uint8_t estado_led = 0;      // 0 = Desligado, 1 = Ligado

// Contadores e Limites de Tempo (em milissegundos)
static uint32_t tempo_decorrido_ms = 0;
static uint32_t duracao_etapa_ms = 0;

// Índice da sequência de pisca
static uint32_t indice_pulso = 0;

// Ponteiro para a matriz de tempos configurada pelo usuário
static PulsosLED *tabela_pulsos = NULL;

// Configura a matriz de tempos que será executada.
void Configura_Matriz_PulsosLED(PulsosLED *matriz)
{
    tabela_pulsos = matriz;
}

// Reinicia e inicia a sequência de pisca a partir do primeiro pulso.
void Configura_Piscadas_PulsosLED(void)
{
    // Garante que existe uma matriz configurada antes de rodar
    if (tabela_pulsos == NULL)
    {
        return;
    }

    indice_pulso = 0;
    tempo_decorrido_ms = 0;

    // Inicia no estado LIGADO
    estado_led = 1;
    duracao_etapa_ms = tabela_pulsos[indice_pulso].tempo_on;

    sequencia_ativa = 1; // Habilita a execução da máquina
}

// Função Periódica (deve ser chamada a cada 1ms).
// Gerencia a alternância entre tempo_on e tempo_off.

void Executa_PulsosLED(void)
{
    // Se a sequência não estiver habilitada, sai imediatamente
    if (!sequencia_ativa)
        return;

    // Incrementa o contador de tempo a cada chamada (1ms)
    tempo_decorrido_ms++;

    // Verifica se o tempo da etapa atual chegou ao fim
    if (tempo_decorrido_ms >= duracao_etapa_ms)
    {
        tempo_decorrido_ms = 0; // Reseta o cronômetro para a próxima etapa

        // SE ESTAVA LIGADO -> Troca para DESLIGADO e carrega o tempo_off
        if (estado_led == 1)
        {
            estado_led = 0;
            duracao_etapa_ms = tabela_pulsos[indice_pulso].tempo_off;
        }
        // SE ESTAVA DESLIGADO -> Avança para o próximo pulso e carrega o tempo_on
        else
        {
            indice_pulso++; // Vai para o próximo item do array

            // CONDIÇÃO DE PARADA: Se encontrou {0, 0}, chegou ao fim do array
            if (tabela_pulsos[indice_pulso].tempo_on == 0 && tabela_pulsos[indice_pulso].tempo_off == 0)
            {
                sequencia_ativa = 0; // Finaliza a execução
                estado_led = 0;      // Garante que o LED termine desligado
                indice_pulso = 0;
            }
            else
            {
                estado_led = 1;
                duracao_etapa_ms = tabela_pulsos[indice_pulso].tempo_on;
            }
        }
    }

    // Atualiza o pino físico com o estado lógico correto em todas as chamadas
    HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, (GPIO_PinState)estado_led);
}