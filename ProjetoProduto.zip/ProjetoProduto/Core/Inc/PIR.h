/*
 * pir.h
 *
 *  Created on: 1 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef PIR_H_
#define PIR_H_
#include "main.h"

typedef struct {
	uint16_t tempo_off;
	uint16_t tempo_on;
} PulsoPIR;

void Executa_PIR(void);
void Configura_Piscadas_PIR(void);
void Configura_Matriz_PIR(PulsoPIR *matriz);

#endif /* PIR_H_ */
