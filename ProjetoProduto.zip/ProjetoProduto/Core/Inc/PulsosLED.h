/*
 * xc.h
 *
 *  Created on: 28 de ago. de 2026
 *      Author: estagiario.epi
 */

#ifndef PulsosLED_H_
#define PulsosLED_H_
#include "main.h"

typedef struct
{
	uint16_t tempo_on;
	uint16_t tempo_off;
} PulsosLED;

void Executa_PulsosLED(void);
void Configura_Piscadas_PulsosLED(void);
void Configura_Matriz_PulsosLED(PulsosLED *matriz);

#endif /* PulsosLED_H_ */
