#ifndef Manager_H
#define Manager_H
#include "main.h"


typedef struct {
    void (*configurar)(void); // Espaço para guardar a função de SETUP
    void (*executar)(void);   // Espaço para guardar a função de AÇÃO
} ModuloPeriferico;

void Gerenciador_Manager(ModuloPeriferico *modulo);

#endif // Manager_H