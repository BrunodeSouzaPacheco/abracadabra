/*
 * botao.h
 *
 *  Created on: 31 de ago. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_BOTAO_H_
#define INC_BOTAO_H_
#include "main.h"

//===========================

//===========================


typedef enum{

	SOLTO = 0,
	PRESSIONADO = 1,
	CLICADO = 2

}clique;

typedef enum {

	PULLDOWN = 0,
	PULLUP = 1

} modo_ligacao;

typedef struct {

	GPIO_TypeDef *porta;
	uint16_t pino;
	uint16_t estado_atual;
	uint16_t estado_anterior;
	uint16_t tempo_para_proximo_estado;
	uint16_t contador;
	uint16_t clique;
	modo_ligacao config_botao;

} botao_t;

//===========================

void Botao_Init(botao_t *btn, GPIO_TypeDef *porta, uint16_t pino,
		uint16_t tempo, modo_ligacao config_botao);

void Botao_Task(botao_t *btn);
void Limpa_Clique(botao_t *btn);

void Task_bot();

#endif /* INC_BOTAO_H_ */
