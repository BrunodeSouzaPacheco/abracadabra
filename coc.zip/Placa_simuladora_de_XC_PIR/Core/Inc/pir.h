/*
 * pir.h
 *
 *  Created on: 1 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_PIR_H_
#define INC_PIR_H_
#include "main.h"

typedef struct
{
  uint32_t tempo_on;
  uint32_t tempo_off;
} pulso_t_pir;

// Definir os valores de tempo para um bit 0 e bit 1
static const pulso_t_pir BIT_0_PIR = {9, 8};
static const pulso_t_pir BIT_1_PIR = {14, 2};
static const pulso_t_pir BIT_START_PIR = {90, 2};
static const pulso_t_pir BIT_FINALIZADOR_PIR = {0, 0};

typedef enum
{
  PIR_ATIVO_BAIXO = 0,
  PIR_ATIVO_ALTO = 1
} nivel_logico_PIR_t;

//==========================

void Task_Pir(void);
void Set_Piscadas_Pir(void);

void setup_pir(pulso_t_pir *matriz, nivel_logico_PIR_t nivel_logico);

#endif /* INC_PIR_H_ */
