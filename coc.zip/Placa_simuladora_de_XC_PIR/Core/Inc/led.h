/*
 * led.h
 *
 *  Created on: 28 de ago. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_LED_H_
#define INC_LED_H_
#include "main.h"

typedef struct {
	uint32_t tempo_on;
	uint32_t tempo_off;
} pulso_t;

//==========================

void Task_led(void);
void Set_piscadas(void);

void setup_led(pulso_t *matriz);

//==========================

#endif /* INC_LED_H_ */
