/*
 * manager_pir.h
 *
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#ifndef INC_MANAGER_PIR_H_
#define INC_MANAGER_PIR_H_

#include "main.h"
#include "pir.h"

#define TAMANHO_VETOR_PIR 21

void Task_Manager_PIR(void);
void Altera_Valor_PIR(int16_t valor);
void Setup_Manager_PIR(nivel_logico_PIR_t nivel_logico);
void set_Piscada_Manager_PIR(void);

#endif /* INC_MANAGER_PIR_H_ */
