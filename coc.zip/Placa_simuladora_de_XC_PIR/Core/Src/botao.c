/*
 * botao.c
 *
 *  Created on: 31 de ago. de 2026
 *      Author: estagiario.epi
 */

#include "botao.h"

void Botao_Init(botao_t *btn, GPIO_TypeDef *porta, uint16_t pino,
		uint16_t tempo, modo_ligacao config_botao) {

	btn->porta = porta;
	btn->pino = pino;
	btn->estado_atual = 1;
	btn->estado_anterior = 1;
	btn->tempo_para_proximo_estado = tempo;
	btn->contador = 0;
	btn->clique = SOLTO;
	btn->config_botao = config_botao;
}

void Botao_Task(botao_t *btn) {

	btn->estado_atual = HAL_GPIO_ReadPin(btn->porta, btn->pino);

	if (btn->estado_atual != btn->estado_anterior) { // Verifica se o estado atual eh diferente do anterior
		btn->contador++;

		if (btn->contador >= btn->tempo_para_proximo_estado) {
			btn->estado_anterior = btn->estado_atual;

			if (!(btn->clique == CLICADO)) {

				if (btn->config_botao == PULLUP) {

					if (btn->estado_anterior == 0) {
						btn->clique = PRESSIONADO;
					}
					if (btn->estado_anterior == 1
							&& btn->clique == PRESSIONADO) {
						btn->clique = CLICADO;
					}
				}
				if (btn->config_botao == PULLDOWN) {

					if (btn->estado_anterior == 1) {
						btn->clique = PRESSIONADO;
					}
					if (btn->estado_anterior == 0
							&& btn->clique == PRESSIONADO) {
						btn->clique = CLICADO;
					}
				}
			}

		}
	}

	else {
		btn->contador = 0;
	}
}

void Limpa_Clique(botao_t *btn) {

	btn->clique = SOLTO;

}

