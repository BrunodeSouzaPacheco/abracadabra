/*
 * pir.c
 *
 *  Created on: 1 de set. de 2026
 *      Author: estagiario.epi
 */

#include "pir.h"

static int habilita_contagem = 0;

static uint32_t contador_de_tempo, tempo_destino, estado_atual, pulso;

static pulso_t_pir *sequencia_pulso = NULL;

static uint32_t LIGAR_PIR = 1;
static uint32_t DESLIGAR_PIR = 0;

void Set_Piscadas_Pir(void) {

	pulso = 0;
	contador_de_tempo = 0;
	tempo_destino = sequencia_pulso[pulso].tempo_on;
	estado_atual = 0;
	habilita_contagem = habilita_contagem ? 0 : 1;
	HAL_GPIO_TogglePin(LED_PIR_GPIO_Port, LED_PIR_Pin);
}

void setup_pir(pulso_t_pir *matriz, nivel_logico_PIR_t nivel_logico) {
	sequencia_pulso = matriz;
	if (nivel_logico == PIR_ATIVO_ALTO) {
		LIGAR_PIR = 1;
		DESLIGAR_PIR = 0;
	} else {
		LIGAR_PIR = 0;
		DESLIGAR_PIR = 1;
	}
}

void Task_Pir(void) {

	if (habilita_contagem >= 1) {
		__disable_irq();

		while (sequencia_pulso[pulso].tempo_on != 0
				&& sequencia_pulso[pulso].tempo_off != 0) {

			/* 1. Liga o pino e aguarda a contagem real de tempo_on */
			HAL_GPIO_WritePin(PIR_GPIO_Port, PIR_Pin, LIGAR_PIR);
			TIM3->CNT = 0;

			tempo_destino = sequencia_pulso[pulso].tempo_on;

			while (TIM3->CNT < tempo_destino) {
			}

			/* 2. Desliga o pino e aguarda a contagem real de tempo_off */
			HAL_GPIO_WritePin(PIR_GPIO_Port, PIR_Pin, DESLIGAR_PIR);
			TIM3->CNT = 0;
			tempo_destino = sequencia_pulso[pulso].tempo_off;
			while (TIM3->CNT < tempo_destino) {
			}

			pulso++;
		}

		HAL_GPIO_WritePin(PIR_GPIO_Port, PIR_Pin, DESLIGAR_PIR);

		// habilita_contagem = 0;

		pulso = 0;
		__enable_irq();
	}
}
