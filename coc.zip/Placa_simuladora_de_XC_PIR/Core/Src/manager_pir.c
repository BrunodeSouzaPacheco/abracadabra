/*
 * manager_pir.c
 *
 *  Created on: 4 de set. de 2026
 *      Author: estagiario.epi
 */

#include "manager_pir.h"

pulso_t_pir VetorPIR[TAMANHO_VETOR_PIR] = {

    BIT_START_PIR,      // Pulso Start
    BIT_1_PIR,          // Pulso 0 - SEMPRE EH 1
    BIT_0_PIR,          // Pulso 1 - SEMPRE EH 0
    BIT_1_PIR,          // Pulso 2
    BIT_0_PIR,          // Pulso 3
    BIT_1_PIR,          // Pulso 4
    BIT_0_PIR,          // Pulso 5
    BIT_1_PIR,          // Pulso 6
    BIT_0_PIR,          // Pulso 7
    BIT_1_PIR,          // Pulso 8
    BIT_0_PIR,          // Pulso 9
    BIT_1_PIR,          // Pulso 10
    BIT_0_PIR,          // Pulso 11
    BIT_1_PIR,          // Pulso 12
    BIT_0_PIR,          // Pulso 13
    BIT_1_PIR,          // Pulso 14
    BIT_0_PIR,          // Pulso 15
    BIT_1_PIR,          // Pulso 16
    BIT_0_PIR,          // Pulso 17
    BIT_0_PIR,          // Pulso 18 - SEMPRE EH 0
    BIT_FINALIZADOR_PIR // Pulso FINALIZADOR
};

void Setup_Manager_PIR(nivel_logico_PIR_t nivel_logico)
{
    setup_pir(VetorPIR, nivel_logico);
}

void Altera_Valor_PIR(int16_t valor)
{
    // 1. Cabeçalho fixo
    VetorPIR[0] = BIT_START_PIR;
    VetorPIR[1] = BIT_1_PIR;
    VetorPIR[2] = BIT_0_PIR;
    // 2. Insere os 16 bits da variável (MSB primeiro, da esquerda para a direita)
    for (int i = 0; i < 16; i++) 
    {
        uint8_t estado_do_bit = (valor >> (15 - i)) & 1;
        if (estado_do_bit == 1) 
        {
            VetorPIR[3 + i] = BIT_1_PIR;
        } 
        else 
        {
            VetorPIR[3 + i] = BIT_0_PIR;
        }
    }
    // 3. Rodapé fixo
    VetorPIR[19] = BIT_0_PIR;
    VetorPIR[20] = BIT_FINALIZADOR_PIR;
}

void Task_Manager_PIR(void)
{
    Task_Pir();
}

void set_Piscada_Manager_PIR(void)
{
    Set_Piscadas_Pir();
}
