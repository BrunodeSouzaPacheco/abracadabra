#include "led.h"

int habilita_contagem;

uint32_t contador_de_tempo;

uint32_t tempo_destino, estado_atual, pulso, maximo_de_pulsos = 10;

static pulso_t *sequencia_pulso = NULL;

void Set_piscadas(void) {

	//if(habilita_contagem) return;
	pulso = 0;
	contador_de_tempo = 0;
	estado_atual = 0;
	tempo_destino = sequencia_pulso[pulso].tempo_on;
	habilita_contagem = 1;

}

void setup_led(pulso_t *matriz) {

	sequencia_pulso = matriz;

}

void Task_led(void) {

	if (habilita_contagem >= 1) {

		if (++contador_de_tempo >= tempo_destino) {

			if (estado_atual == 0) {  //Estava Ligado

				tempo_destino = sequencia_pulso[pulso].tempo_off;

				estado_atual = 1; // Ir para o estado de Desligado
				contador_de_tempo = 0;
			} else { //Estava desligado

				pulso++;
				if (sequencia_pulso[pulso].tempo_on == 0
						&& sequencia_pulso[pulso].tempo_off == 0) { //Chegou no ultimo item
					habilita_contagem = 0;
					pulso = 0;
				}

				tempo_destino = sequencia_pulso[pulso].tempo_on;
				estado_atual = 0; // Ir para o estado de LIGADO
				contador_de_tempo = 0;
			}

		}

		else {
			HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, estado_atual);
		}
	}
}
